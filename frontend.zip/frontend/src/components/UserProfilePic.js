import React from 'react'

const UserProfilePic = ({profilePic}) => {

  
  return (
    <div>
      {profilePic}
    </div>
  )
}

export default ProfilePic
