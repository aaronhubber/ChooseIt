import React from 'react'

const ScheduleContainer = () => {
  return (
    <div>
      <h3>I a a schedule container</h3>
    </div>
  )
}

export default ScheduleContainer
